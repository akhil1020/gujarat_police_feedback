<?php
$conn = new mysqli('localhost', 'root', '', 'qrfeedback');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$cpassword = $_POST['cpassword'];

$existSql = "SELECT * FROM login_detail WHERE email = ?";
$stmt = $conn->prepare($existSql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$numExistRows = $result->num_rows;

if ($numExistRows > 0) {
    echo "Email Already Exists"; //Corrected error message
} else {
    if ($password === $cpassword) {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert into the database
        $sql = "INSERT INTO login_detail (name, email, password) VALUES (?, ?, ?)"; //Corrected INSERT statement
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $name, $email, $hash); //Bind all three parameters
        $result = $stmt->execute();

        if (password_verify($entered_password, $stored_password)) {
            echo "Account created successfully";
        }
    } else {
        echo "Passwords do not match";
    }
}
?>





